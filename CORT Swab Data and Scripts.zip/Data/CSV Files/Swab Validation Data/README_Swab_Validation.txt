### Swab Validation ###

The files contained here represent data that test the biochemical viability of rayon swabs and whether enough mucus or hormone is washed off during any amphibian washing steps in other protocols. 

### Cort_Swab_Validation_071123.csv ###

The data present in this file were used to determine if rayon was an adequate material for uptaking corticosterone from different medium types. Two types, water and mucus, were the primary experimental groups, as both compounds are present on amphibian skin. Assay buffer was the positive control, as it was a chemically defined medium that is known to be able to hold corticosterone in solution. 

# Metadata meaning

Treatment - The medium type (Swab Only, Mucus, Water, or Buffer) and whether or not the sample was spiked with corticosterone (Spiked and Unspiked)
CORT - The concentration of corticosterone determine via ELISA. Values are measured in pg/ml
%B/B0 - The saturation of the ELISA assay; in other words, where on the linear range the observed corticosterone values fall
Dilution - Dilution factor used to load the samples into each well on the ELISA
StdDev - The standard deviation of observed corticosterone values. Values are measured in pg/ml
%CV - The percent coefficient of variation. This gives you an idea of how consistent the measured corticosterone values were
SEM - The standard error of the mean for each measured corticosterone value. Values are measured in pg/ml
Status - Whether or not the sample was spiked with 600 pg/ml of corticosterone, or unspiked 
Medium - What type of medium the sample was (Swab [not exposed to any medium type], Mucus, Buffer, or Water)

# Methods

To determine if rayon   can effectively adsorb steroid hormones, we conducted a study using three different types of swabbing medium samples. This included mucus collected from 12 captive newts, water with the same parameters as the newts' housing, and ELISA buffer (Cayman Chemical Company). Newt mucus was collected in a 50 ml conical using a cell scraper to gently rub the mucus off the newts. To do this, we restrained newts by their tails with their heads facing toward the inside of the tube. After holding the conical at an angle to allow the newts to rest their stomachs at the top, we gently scraped their dorsal and ventral surfaces. Once mucus coated the scraper, the newt was removed and placed back into its respective holding tub and the mucus was smeared onto the bottom of the conical. Since we house the newts in aquatic set-ups, some housing water got into the sample, although this reflects what would be obtained through dermal swabbing if an adult newt were immediately swabbed after capture in the field. 1X ELISA buffer was made from a 10X stock diluted into MiliQ water according to instructions from the corticosterone Cayman Chemical ELISA kit. Water used to house newts was obtained directly from the water storage tank in the animal care facility containing reverse-osmosis water reconstituted with dilute salts and sodium hydroxide to the above-mentioned pH and conductivity. In total, 800 μL of each medium type was collected.
We also included three swabs that were not used to swab anything ('neat') as a control to measure the background produced by the swab itself. Each swab type (excluding 'neat' swabs) was further split into two 400 μL samples: one spiked with 600 pg/ml of CORT, and one without any spike. We placed 400 μL of each sample type into sterile petri dishes and used three sterile CLASSICQSwabs to rub the surface of the dish. The medium was streaked across the dish surface three times before flipping the swabs over and swabbing it three more times. Next, we placed the swabs into 1.5 ml microcentrifuge tubes containing 500 μL of 70% ethanol and stored them at 4°C overnight for hormone extraction. 
The next day, we removed the swabs from the ethanol solution and split the 'neat' swab samples into two 250 μL samples: one spiked with 2500 pg/ml into the ethanol and one without a spike to determine extraction efficiency. We then placed all tubes into a SpeedVac and allowed the ethanol to evaporate under vacuum for 3 hours at 60°C. We reconstituted the samples in proportionate volumes of 1X ELISA buffer (Cayman Chemical Company), vortexed them for 1 minute, sonicated them for 20 minutes, and left them to shake at 150 rpm  on an orbital shaker (Carolina Orbital Shaker, Item # 216230) for 30 minutes to reconstitute the hormone. Finally, we stored the samples at 4°C for future use. 
Once all samples were reconstituted, we ran each sample on a CORT ELISA from Cayman Chemical Company. We loaded 50 μL of each sample into each well and ran them in triplicate. We read the plates on a POLARstar Omega plate reader at 412 nm according to the manufacturer's instructions. We recorded the resulting absorbance values on a spreadsheet. All samples were run 'neat'.

### Wash-Experiment_Summary_061523.csv ###

The data stored in this file were used to determine if a 30 minute wash in sterile water was enough to remove any potential corticosterone present on the skin in Eastern newts. This was important, as the second round of field swabs (the 30 minute swabs) showed no demonstrable difference in the amount of corticosterone present. Therefore, it was important to determine if the sterile water wash was responsible for this loss of signal. 

# Metadata meaning

Sample - Identification numbers of newts that were housed in the animal facility
Wash - Whether or not a newt was assigned to a sterile water bath (Washed) treatment, or not (Unwashed)
Treatment - Whether or not the swab extracts received a 2,500 ng/ml corticosterone spike prior to extraction to determine the extraction efficiency of our swab processing protocol. Extracts were split into Spiked and Unspiked groups
[CORT] - The concentration of corticosterone detected via ELISA. Values are measured in pg/ml
Time - Whether or not the sample was taken before treatment (0 minutes) or after treatment (30 minutes). 

# Methods 

To determine if the mucus washes performed in the field had an impact on dermal CORT readings, 12 newts that had been living on the Aquaneering system for more than a year were selected for testing. One group was placed in a whirlpack filled with sterile artificial pond water (Wyngaard & Chinnappa, 1982),   while the other group was returned to the holding tank they were taken from after their baseline CORT swab was obtained. After 30 minutes, the newts were swabbed again and put back in their holding tanks. Once the experiment was finished, the newts were given water changes and fed. All swabs were extracted    as mentioned in the previous section, spiked to examine extraction efficiency, and immediately analyzed using an ELISA. 