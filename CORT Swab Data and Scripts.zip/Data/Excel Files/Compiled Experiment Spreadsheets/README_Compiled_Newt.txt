### The Compiled Experimental Data from the 2023 Eastern Newt (Notophthalmus viridescens viridescens) Experiments ###

The provided spreadsheet contains all of the raw data in addition to the metadata collected from the summer of 2023. There are 6 tabs provided, with each arranged in a tabular format. 

### Compiled Data ###

The first tab contains all of the data that was used in the ACTH_Injection_data.csv file. This file was used to determine whether or not corticosterone swabbed from the skin of Eastern newts was related to the physiology of the HPI (Hypothalamus-Pituitary-Interrenal) axis. This is highly relevant to conservation biologists, as obtaining corticosterone via other means (blood, urine, saliva, or feces) is incredibly difficult with amphibians that have a mass of less than 5 grams. 

# Metadata meaning

Newt_ID - The identification number given to each individual newt used in the study
SVL - Snout-Vent Length, measured in millimeters
Weight - Weight of each newt, measured in grams
Sex - Male (M), Female (F), or Juvenile/Indeterminate (J)
Bd_Field - The starting Batrachochytrium dendrobatidis (Bd) copy numbers detected via qPCR, measured in number of starting copies; this data was obtained from skin swabs taken in the field 30 minutes after capture. 
Bd_Week 2 - The starting Bd copy numbers detected via qPCR, measured in number of starting copies; this data was obtained right from skin swabs taken after the acclimation period in captivity, which spanned 2 weeks. 
Cort_Field - The amount of corticosterone detected from dermal swabs taken upon capture in the field (a theoretical measure of baseline corticosterone). Data was obtained from Enzyme Linked Immunosorbent Assays (ELISAs). All raw ELISA data is provided in a separate spreadsheet in the Hormone Titer Spreadsheets folder. Values are measured in pg/ml 
Cort_0_Week3 - The amount of corticosterone detected from dermal swabs taken one week after the acclimation period (Week 3 of captivity). The 0 represents timepoint 0 hours, as these swabs were used as a baseline for the amount of corticosterone present on the skin prior to experimental manipulations.Values are measured in pg/ml
Cort_(0.5-24) - The amount of corticosterone detected from dermal swabs taken after injections with different compounds (0.9% Saline, which was the control; Corticosterone, which was an excretion (positive) control; and Adrenocorticotropin Hormone (ACTH), which was our experimental group). 0.5, 1, 2, 3, 6, and 24 are all hours after injection. Values are measured in pg/ml
Status_(w1-w4) - Whether or not a newt was dead or alive on a given week after the injection experiment (Weeks 3 - 7 of captivity; this column is incomplete and was ommitted from further analysis). 
Group - The injection type a given newt received during the injection experiment. None - The newt perished before the experiment began, ACTH - 1 IU/kg Adrenocorticotropin Hormone, Saline - 0.9% Saline, CORT - 446 ng/g Corticosterone
Cortisol_(Field - 24) - The amount of cortisol detected from dermal swabs taken both during the field, acclimation period, and injection experiment. No cortisol was detected from the ELISAs, which are represented by NA values. 

# Methods
See the README for the ACTH_Injection_data.csv file. 

### Wash Assay ###

The second tab contains all of the data used in the Wash_Experiment_Summary_061523.csv file. The data stored in this file were used to determine if a 30 minute wash in sterile water was enough to remove any potential corticosterone present on the skin in Eastern newts. This was important, as the second round of field swabs (the 30 minute swabs) showed no demonstrable difference in the amount of corticosterone present. Therefore, it was important to determine if the sterile water wash was responsible for this loss of signal. 

# Metadata meaning

Sample - Identification numbers of newts that were housed in the animal facility
Wash - Whether or not a newt was assigned to a sterile water bath (Washed) treatment, or not (Unwashed)
Treatment - Whether or not the swab extracts received a 2,500 ng/ml corticosterone spike prior to extraction to determine the extraction efficiency of our swab processing protocol. Extracts were split into Spiked and Unspiked groups
[CORT] - The concentration of corticosterone detected via ELISA. Values are measured in pg/ml
Time - Whether or not the sample was taken before treatment (0 minutes) or after treatment (30 minutes). 

# Methods 
See the README for the Wash_Experiment_Summary_061523.csv file. 

### Field Data ###

The third tab contains all data obtained from the field during the capture of the Eastern newts in May 2023.

# Metadata meaning

Newt_ID - Identification numbers assigned to Eastern newts
Sex - Male (M), Female (F), or Juvenile/Indeterminate (J)
Mass Total (g) - The total mass of newts as measured while they were in bags post-capture. Values are recorded in grams
Mass Whirlpack (g) - The mass of the bags each individual newt was once present in. Values are recorded in grams
Mass Newt (g) - The mass of the newts as calculated by the following equation: Mass Total - Mass Whirlpack. Values are recorded in grams
SVL (mm) - Snout-Vent length, measured in millimeters
Comments - Any notable observations regarding each newt, such as the presence or absence of parasites, whether the individual was gravid with eggs, or dropped during handling

Below the table are some summary statistics, such as the proportion of males to females, the averages for both newt mass and SVL, and the standard deviations of the masses and SVLs. 

# Methods

To measure the natural variation in CORT obtained through dermal swabbing, we collected Eastern newts (Notophthalmus viridescens viridescens) from the George D. Aiken Wilderness in Woodford, Vermont in May 2023. We measured water parameters such as temperature, pH, and conductivity before sampling using a handheld probe. Adult newts were caught through dip-netting and promptly swabbed for baseline CORT after capture. We recorded their SVL, weights, and sex, then placed them into whirlpacks containing 30 ml of sterile artificial pond water for the collection of dermal mucus, which was used for a separate project. After 30 minutes, we re-swabbed the newts for CORT and swabbed for both Bd and the microbiome. We then placed them into whirlpacks containing water from the surrounding bog and transported them back to the lab in a cooler. After 6 hours, we swabbed the newts for CORT and drip acclimated them onto a flow-through aquarium (Aquaneering) system. Bd/microbiome swabs were obtained using sterile Dryswabs from medicalwire and CORT swabs were obtained using CLASSIQSwabs from Copan Diagnostics. 

### Matrix Data ###

The fourth tab contains data from the Cort_Swab_Validation_071123.csv file. The data present in this file were used to determine if rayon was an adequate material for uptaking corticosterone from different medium types. Two types, water and mucus, were the primary experimental groups, as both compounds are present on amphibian skin. Assay buffer was the positive control, as it was a chemically defined medium that is known to be able to hold corticosterone in solution. 

# Metadata meaning

Treatment - The medium type (Swab Only, Mucus, Water, or Buffer) and whether or not the sample was spiked with corticosterone (Spiked and Unspiked)
CORT - The concentration of corticosterone determine via ELISA. Values are measured in pg/ml
%B/B0 - The saturation of the ELISA assay; in other words, where on the linear range the observed corticosterone values fall
Dilution - Dilution factor used to load the samples into each well on the ELISA
StdDev - The standard deviation of observed corticosterone values. Values are measured in pg/ml
%CV - The percent coefficient of variation. This gives you an idea of how consistent the measured corticosterone values were
SEM - The standard error of the mean for each measured corticosterone value. Values are measured in pg/ml
Status - Whether or not the sample was spiked with 600 pg/ml of corticosterone, or unspiked 
Medium - What type of medium the sample was (Swab [not exposed to any medium type], Mucus, Buffer, or Water)

# Methods

To determine if rayon   can effectively adsorb steroid hormones, we conducted a study using three different types of swabbing medium samples. This included mucus collected from 12 captive newts, water with the same parameters as the newts' housing, and ELISA buffer (Cayman Chemical Company). Newt mucus was collected in a 50 ml conical using a cell scraper to gently rub the mucus off the newts. To do this, we restrained newts by their tails with their heads facing toward the inside of the tube. After holding the conical at an angle to allow the newts to rest their stomachs at the top, we gently scraped their dorsal and ventral surfaces. Once mucus coated the scraper, the newt was removed and placed back into its respective holding tub and the mucus was smeared onto the bottom of the conical. Since we house the newts in aquatic set-ups, some housing water got into the sample, although this reflects what would be obtained through dermal swabbing if an adult newt were immediately swabbed after capture in the field. 1X ELISA buffer was made from a 10X stock diluted into MiliQ water according to instructions from the corticosterone Cayman Chemical ELISA kit. Water used to house newts was obtained directly from the water storage tank in the animal care facility containing reverse-osmosis water reconstituted with dilute salts and sodium hydroxide to the above-mentioned pH and conductivity. In total, 800 μL of each medium type was collected.
We also included three swabs that were not used to swab anything ('neat') as a control to measure the background produced by the swab itself. Each swab type (excluding 'neat' swabs) was further split into two 400 μL samples: one spiked with 600 pg/ml of CORT, and one without any spike. We placed 400 μL of each sample type into sterile petri dishes and used three sterile CLASSICQSwabs to rub the surface of the dish. The medium was streaked across the dish surface three times before flipping the swabs over and swabbing it three more times. Next, we placed the swabs into 1.5 ml microcentrifuge tubes containing 500 μL of 70% ethanol and stored them at 4°C overnight for hormone extraction. 
The next day, we removed the swabs from the ethanol solution and split the 'neat' swab samples into two 250 μL samples: one spiked with 2500 pg/ml into the ethanol and one without a spike to determine extraction efficiency. We then placed all tubes into a SpeedVac and allowed the ethanol to evaporate under vacuum for 3 hours at 60°C. We reconstituted the samples in proportionate volumes of 1X ELISA buffer (Cayman Chemical Company), vortexed them for 1 minute, sonicated them for 20 minutes, and left them to shake at 150 rpm  on an orbital shaker (Carolina Orbital Shaker, Item # 216230) for 30 minutes to reconstitute the hormone. Finally, we stored the samples at 4°C for future use. 
Once all samples were reconstituted, we ran each sample on a CORT ELISA from Cayman Chemical Company. We loaded 50 μL of each sample into each well and ran them in triplicate. We read the plates on a POLARstar Omega plate reader at 412 nm according to the manufacturer's instructions. We recorded the resulting absorbance values on a spreadsheet. All samples were run 'neat'.  

### qPCR Data ###

The fifth tab contains data compiled from the Bd_Sq_Values spreadsheet located in the Infection Load Spreadsheets folder. The goal of this data was to determine the Batrachochytrium dendrobatidis (Bd) load of each individual newt. All newts ended up infected with Bd throughout the duration of the experiment. 

# Metadata meaning

The first section of the spreadsheet contains tables for the measured Cqs of the standards on each qPCR plate. 

Copy# - The known starting copy number for each standard
Sample 1 - The first standard column on the plate
Sample 2 - The second standard column on the plate
Average - The average Cq values for samples 1 and 2
StdDev - The standard deviation of the Cq values for samples 1 and 2
T1-T13; Field Acc; Acc 1 - 24 - The names of each qPCR plate according to which samples were on them

The second section of the spreadsheet contains a table for the calculated Sq values based on the standard tables in the first section of the spreadsheet. 

Newt ID - Identification numbers assigned to individual Eastern newts
Field Average - The average Cq values obtained via qPCR from DNA samples swabbed from newts in the field
Acc Average - The average Cq values obtained via qPCR from DNA samples swabbed from newts during their second week in captivity
Sq Field - The calculated Sq (starting copy) values from DNA samples swabbed from newts in the field. These values were calculated according to the standard curves generated from the tables in the first section. 
Sq Acc - The calculated (starting copy) values from DNA samples swabbed from newts during their second week in captivity. These values were calculated according to the standard curves generated from the tables in the first section.

The third section of the data contains 3 cells that contain the regression equations for each standard curve. 


# Methods

DNA was extracted from Bd/microbiome swabs using the gMax Mini extraction Kit (IBI Scientific). Swabs were suspended in an extraction buffer containing lysozyme followed by an incubation at 37°C for an hour. Afterward, the extraction supernatants were loaded onto spin columns, washed twice, and then eluted to obtain purified DNA extracts according to the manufacturer’s instructions. All extracts were stored at -20°C for long-term storage. 
To determine infection load, qPCR was performed following Boyle et al. (2004): 5 μL of sample was used for 25 μL total reactions using the ITS forward and reverse primers in Taqman Master Mix. To detect DNA amplification, FAM was used as the fluorescent reporter.  The plates were run on a C1000 Touch Thermal Cycler (BIO-RAD).

### Survival Data ### 

The sixth, and final, tab contains data from the Survival_Analysis_Data.csv file. This data was collected for the purpose of determining whether or not corticosterone swabbed from the skin is predictive of newt survival in captivity. 

# Metadata meaning

Newt_ID - Identification numbers assigned to individual newts
Sex - Male (M), Female (F), or Juvenile/Indeterminate (J)
Mass - Mass of each individual newt, measured in grams
SVL - Snout-Vent length, measured in millimeters
Date Collected - The field collection date for each individual newt
End Date - The last recorded observation date of a living newt 
Status - Either 1 (the newt survived to 8/8/2023) or 0 (the newt died prior to 8/8/2023)
Load Field - The number of Bd starting copy numbers obtained from field DNA swabs
Load Acc - The number of Bd starting copy numbers obtained from DNA swabs taken during the newt acclimation period (Week 1)
Cort_Field - The concentration of corticosterone determined via ELISA from field corticosterone swabs, measured in pg/ml
Cort_W1 - The concentration of corticosterone determined via ELISA taken from swabs during the newt acclimation period (Week 1), measured in pg/ml

# Methods

On the Aquaneering system, we housed the newts at 18°C and changed the water twice a week. The water parameters consisted of a pH range of 7.4 - 7.6 and conductivity of 300 µs/cm. The newts were kept in 0.8 L holding tanks with 3 cm by 3 cm styrofoam floats. After each water change, we fed them bloodworms thawed in system water and allowed them to acclimate for 3 weeks before conducting experiments. Dermal swabs were obtained each week to gauge changes in dermal CORT over time. 

After experimentation on the 3rd week, newts were monitored for an additional 7 weeks post experimentation to determine if corticosterone measured on the skin during the acclimation or field sampling periods was predictive of future survival in captivity. 

