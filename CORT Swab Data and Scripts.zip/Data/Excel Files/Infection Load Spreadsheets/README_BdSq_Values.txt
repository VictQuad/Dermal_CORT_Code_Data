### qPCR Data ###

The goal of this data was to determine the Batrachochytrium dendrobatidis (Bd) load of each individual newt. All newts ended up infected with Bd throughout the duration of the experiment. 

# Metadata meaning

The first section of the spreadsheet contains tables for the measured Cqs of the standards on each qPCR plate. 

Copy# - The known starting copy number for each standard
Sample 1 - The first standard column on the plate
Sample 2 - The second standard column on the plate
Average - The average Cq values for samples 1 and 2
StdDev - The standard deviation of the Cq values for samples 1 and 2
T1-T13; Field Acc; Acc 1 - 24 - The names of each qPCR plate according to which samples were on them

The second section of the spreadsheet contains a table for the calculated Sq values based on the standard tables in the first section of the spreadsheet. 

Newt ID - Identification numbers assigned to individual Eastern newts
Field Average - The average Cq values obtained via qPCR from DNA samples swabbed from newts in the field
Acc Average - The average Cq values obtained via qPCR from DNA samples swabbed from newts during their second week in captivity
Sq Field - The calculated Sq (starting copy) values from DNA samples swabbed from newts in the field. These values were calculated according to the standard curves generated from the tables in the first section. 
Sq Acc - The calculated (starting copy) values from DNA samples swabbed from newts during their second week in captivity. These values were calculated according to the standard curves generated from the tables in the first section.

The third section of the data contains 3 cells that contain the regression equations for each standard curve. 

The other tabs contain the fitted curves that contain the regression equations obtained from the standards from each plate. 

# Methods

DNA was extracted from Bd/microbiome swabs using the gMax Mini extraction Kit (IBI Scientific). Swabs were suspended in an extraction buffer containing lysozyme followed by an incubation at 37°C for an hour. Afterward, the extraction supernatants were loaded onto spin columns, washed twice, and then eluted to obtain purified DNA extracts according to the manufacturer’s instructions. All extracts were stored at -20°C for long-term storage. 
To determine infection load, qPCR was performed following Boyle et al. (2004): 5 μL of sample was used for 25 μL total reactions using the ITS forward and reverse primers in Taqman Master Mix. To detect DNA amplification, FAM was used as the fluorescent reporter.  The plates were run on a C1000 Touch Thermal Cycler (BIO-RAD).
