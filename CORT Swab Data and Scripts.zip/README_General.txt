### Evaluating the Use of Skin Swabbing to Measure Stress in Wild Amphibians - Data used in Publication ###

The shared file is split among two different folders: a data folder, which contains both Excel spreadsheets and CSV files that hold the data used in the publication, and a scripts folder, which includes all of the code used for statistical analyses and figure generation. Excel spreadsheets are included for broader accessibility, as some folks who may be interested in using the provided data may not be R savvy. 

Instructions for each script and dataset are given in READMEs that are nested within the folders. Each README contains information regarding:

1) Metadata - What do certain symbols or dummy coded variables mean? 
2) Script Information - Why were certain packages used? What statistics were run?  
3) Methods - How was the data collected? What was the experimental design?

Once the manuscript gets published, a link to the article will be provided for further context. 