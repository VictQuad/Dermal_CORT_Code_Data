### The Summer 2022 Experiment Code ### 

This experiment inspired the injection assay that took place the following summer in 2023. This script was made for a class. 

### Summer_2022_Mesocosm_Analysis.R ###

This script was meant for the TidyTufts.csv file. The methods associated with that file can be found in the README for that file. 

The packages utilized in this script include pacman, the tidyverse, performance, visreg, ggthemes, glmmTMB, emmeans, lme4, and AICcmodavg. Each package was used for a specific purpose:

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
emmeans - for estimating confidence intervals 
performance - for evaluating linear model assumptions
glmmTMB - for creating generalized linear models and mixed effects models
ggthemes - for adding more theme options for ggplot plots
AICcmodavg - for obtaining AIC values
visreg - used for quickly displaying the fit of linear models
lme4 - for creating mixed effects models

The script is split into a few different parts:

1) Loading the necessary packages, cleaning the data, and summary visualizations of the data
2) Analysis of the effects of different treatment groups on the amount of corticosterone measured from skin swabs