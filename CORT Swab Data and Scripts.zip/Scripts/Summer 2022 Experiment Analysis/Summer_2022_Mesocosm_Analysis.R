### Load in Libraries and Settings ###
library(pacman)
p_load(tidyverse, performance, visreg,
       ggthemes, glmmTMB, emmeans, 
       lme4, AICcmodavg)

theme_set(theme_clean())
### Load in Data ###
Tufts <- read_csv("") %>% #Load in TidyTufts.csv
  mutate(Week = as.character(Week))
  
str(Tufts)
head(Tufts)
#SVL did not change, so body condition is dependent solely upon change in body mass
### Examine and Manipulate Data ###
Treatment_plot <- ggplot(data = Tufts,
                         mapping = aes(x = Treatment,
                                       y = `[Cort]`,
                                       fill = Treatment)) +
  geom_boxplot() +
  facet_wrap(~Week) +
  labs(x = 'Treatment Group',
       y = "[Corticosterone] (pg/ml)")
Treatment_plot #okay, looks like with time, cort decreased. Are differences significant between treaments?
Position_plot <- ggplot(data = Tufts,
                        mapping = aes(x = Position,
                                      y = `[Cort]`,
                                      fill = Position)) +
  geom_boxplot() +
  facet_wrap(~`Week`) +
  labs(x = "Position",
       y = "[Corticosterone] (pg/ml)")
Position_plot #looks like there are no edge effects - phew
Mass_plot <- ggplot(data = Tufts,
                    mapping = aes(x = `Delta Mass`,
                                  y = `[Cort]`,
                                  color = `Sex`)) +
  geom_point() +
  facet_wrap(~Treatment) +
  stat_smooth(method = "lm") +
  labs(x = "ΔMass (grams)",
       y = "[Corticosterone] (pg/ml)")
Mass_plot #looks like there is little to no correlation between corticosterone and a change in mass
Temp_plot <- ggplot(data = Tufts,
                    mapping = aes(x = `Temperature`,
                                  y = `[Cort]`,
                                  group = `Temperature`,
                                  fill = Week)) +
  facet_wrap(~Treatment) +
  geom_boxplot() +
  labs(x = "Temperature (°C)",
       y = "[Corticosterone] (pg/ml)")
Temp_plot #looks like there is an interaction with week and temperature
temp_week <- ggplot(data = Tufts,
                    mapping = aes(x = as.numeric(`Week`),
                                  y = `Temperature`)) +
 geom_line() +
  labs(x = "Week #",
       y = "Temperature (°C)")
temp_week

sex_plot <- ggplot(data = Tufts,
                   mapping = aes(x = Sex,
                                 y = `[Cort]`,
                                 fill = Sex)) +
  facet_wrap(~Week) +
  geom_boxplot() +
  labs(x = "Sex",
       y = "[Corticosterone] pg/ml")
sex_plot #appears to be an initial difference, but it disappears after the 0th week
sex_treatment <- ggplot(data = Tufts,
                        mapping = aes(x = Sex,
                                      y = `[Cort]`)) +
  facet_wrap(~Treatment) +
  geom_boxplot()
sex_treatment #looks like there is not really a difference according to treatment
### Fit Linear-Mixed Model ###
cort_lme1 <- glmmTMB(`[Cort]` ~ Treatment*Week + Sex + (1|Newt.ID),
                     data = Tufts) 
cort_lme2 <- glmmTMB(`[Cort]` ~ Treatment + Week + Sex + (1|Newt.ID),
                     data = Tufts) #best fit model
cort_lme3 <- glmmTMB(`[Cort]` ~ Sex*Treatment + Week + (1|Newt.ID),
                     data = Tufts)
cort_lme4 <- glmmTMB(`[Cort]` ~ Treatment*Week*Sex + (1|Newt.ID),
                     data = Tufts)
modlist <- list(cort_lme1,
                cort_lme2,
                cort_lme3,
                cort_lme4)
modnames <- 1:4

aictab(cand.set = modlist,
       modnames = modnames,
       second.ord = FALSE) #lme2 was the best

check_model(cort_lme2) #looks good
summary(cort_lme2) #looks interesting
### Visualize and Query ###
emmeans(cort_lme2, specs=~ Treatment|Week) %>%
  contrast("pairwise") %>%
  confint() %>%
  plot() +
  geom_vline(xintercept = 0,lty = 2, color = "red")#there is still no significant effect

emmeans(cort_lme2, specs =~ Sex|Week) %>%
  contrast("pairwise") %>%
  confint() %>%
  plot() +
  geom_vline(xintercept = 0,lty = 2, color = "red")

emmeans(cort_lme2, specs=~ Treatment|Sex) %>%
  contrast("pairwise") %>%
  confint() %>%
  plot() +
  geom_vline(xintercept = 0,lty = 2, color = "red")

