### Load in Packages + Settings ###
library(pacman)
p_load(tidyverse, emmeans, performance,
       glmmTMB, ggthemes, ggsignif, plotrix, 
       wrappedtools, CR2, lme4, bbmle)
theme_set(theme_clean())
set.seed(101823)

### Load in and clean the data ### 
Injections <- read_csv("") # load in Leopard_Frog_Data.csv

Injections_long <- Injections |>
  pivot_longer(names_to = "Time_corticosterone",
               values_to = "Corticosterone",
               cols = starts_with("Cort_"))

Cort_Val <- Injections_long |>
  mutate(Time_corticosterone = recode(Time_corticosterone,
                                      "Cort_0" = 0,
                                      "Cort_0.5" = 0.5,
                                      "Cort_1" = 1,
                                      "Cort_2" = 2,
                                      "Cort_3" = 3,
                                      "Cort_6" = 6,
                                      "Cort_24" = 24)) |>
  mutate(Time_corticosterone = as.factor(Time_corticosterone)) |>
  group_by(Group, Time_corticosterone) |>
  mutate(Med_cort = median(Corticosterone, na.rm = TRUE),
         Stem_cort = medianse(Corticosterone),
         Mean_cort = mean(Corticosterone, na.rm = TRUE),
         Ste_cort = std.error(Corticosterone, na.rm = TRUE)) |>
  ungroup() # This makes the data more amenable to plotting

### Visualize the data ###
dynamics <- ggplot(data = Cort_Val,
                   mapping = aes(x = Time_corticosterone,
                                 y = Med_cort,
                                 color = Group)) +
  geom_point() +
  geom_line(mapping = aes(group = Group),
            linewidth = 0.6) +
  geom_errorbar(aes(ymax = Med_cort + Stem_cort,
                    ymin = Med_cort - Stem_cort),
                linewidth = 0.6) +
  labs(title = "Dynamics of Corticosterone Detected through Mucus Swabs",
       subtitle = "Data obtained from Lithobates pipiens",
       x = "Time (hours)",
       y = "Median Corticosterone(pg/ml)")
dynamics + scale_color_colorblind()

dynamics2 <- ggplot(data = Cort_Val,
                    mapping = aes(x = Time_corticosterone,
                                  y = Mean_cort,
                                  color = Group)) +
  geom_point() +
  geom_line(mapping = aes(group = Group),
            linewidth = 0.6) +
  geom_errorbar(aes(ymax = Mean_cort + Ste_cort,
                    ymin = Mean_cort - Ste_cort),
                linewidth = 0.6) +
  labs(x = "Time (hours)",
       y = "Mean Corticosterone(pg/ml)")
dynamics2 + scale_color_colorblind()

treatment_effects <- ggplot(data = Cort_Val,
                            mapping = aes(x = Group,
                                          y = Corticosterone,
                                          fill = Group)) +
  geom_boxplot() +
  labs(title = "CORT Detected According to Treatment",
       subtitle = "Obtained from Lithobates pipiens",
       x = "Injection Group",
       y = "Corticosterone (pg/ml)")

treatment_effects

### Analysis ###
cortbd_s <- lm(Corticosterone ~ SVL,
               data = Cort_Val)

cortbd_w <- lm(Corticosterone ~ `Mass(frog)`,
               data = Cort_Val)
check_model(cortbd_w)
check_model(cortbd_s) 
summary(cortbd_s)
summary(cortbd_w)
AICctab(cortbd_s, cortbd_w)
#Physiological Validation Models#
cortval_lm1 <- lm(log(Corticosterone) ~ Group + Time_corticosterone,
                  data = Cort_Val)
check_model(cortval_lm1)
cortval_lm2 <- lm(log(Corticosterone) ~ Group + Time_corticosterone + SVL,
                  data = Cort_Val)
check_model(cortval_lm2)
cortval_lm3 <- lm(log(Corticosterone) ~ Time_corticosterone + SVL,
                  data = Cort_Val)
check_model(cortval_lm3)
cortval_lm4 <- lm(log(Corticosterone) ~ Group,
                  data = Cort_Val)
check_model(cortval_lm4)
cortval_lme1 <- lmer(log(Corticosterone) ~ Group + Time_corticosterone + (1|Frog_ID),
                     data = Cort_Val)
check_model(cortval_lme1)
cortval_lme2 <- lmer(log(Corticosterone) ~ Group + Time_corticosterone + SVL + (1|Frog_ID),
                     data = Cort_Val)
check_model(cortval_lme2)
cortval_lme3 <- lmer(log(Corticosterone) ~ Group + (1|Frog_ID),
                     data = Cort_Val)
check_model(cortval_lme3)
AICctab(cortval_lm1, cortval_lm2, cortval_lm3, cortval_lm4, cortval_lme1,cortval_lme2,cortval_lme3)

check_heteroscedasticity(cortval_lme1)

emmeans(cortval_lm1, specs = ~Group) |>
  contrast(method = "trt.vs.ctrl") |>
  confint() |>
  plot() +
  geom_vline(xintercept = 0, color = "red", lty = 2) +
  labs(x = "Estimated Difference in Mean Corticosterone",
       y = "Groups Compared")
