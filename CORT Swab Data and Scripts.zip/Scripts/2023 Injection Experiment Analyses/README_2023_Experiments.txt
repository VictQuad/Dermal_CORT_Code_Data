### Summer 2023 Script Information ###

The 3 R files provided in this folder were used to analyze experimental data obtained from both Eastern newts (Notophthalmus viridescens viridescens) and Northern leopard frogs (Rana (Lithobates) pipiens). Each script is dedicated to both different types of package environments and different species. 

### Eastern_Newt_Swab_Analysis.R and Leopard_Frog_Swab_Analysis.R ### 

Both of these scripts share much of the same code. This is because the type of analysis performed was the same, save for a few differences. These differences include: 

1) Species differences (one was used for Eastern newt data, the other was used for leopard frog data)
2) Dataset differences (one had infection load values and survival data, another did not)
3) Pipeline differences (the Eastern newt data needed an additional set of statistics for the additional data obtained)

# Eastern_Newt_Swab_Analysis.R details

To use the script, load in ACTH_Injection_data.csv. For more information regarding the data, look at the README found in association with the data file. 

The packages utilized in this script include pacman, the tidyverse, emmeans, performance, glmmTMB, ggthemes, ggsignif, plotrix, wrappedtools, CR2, lme4, ggpmisc, and bbmle. Each package was used for specific purposes:

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
emmeans - for estimating confidence intervals 
performance - for evaluating linear model assumptions
glmmTMB - for creating generalized linear models and mixed effects models
ggthemes - for adding more theme options for ggplot plots
ggsignif - for estimating statistical significance and plotting p-values on graphs made with ggplot
plotrix - for estimate standard error of the median
wrappedtools - for creating tables 
CR2 - for estimating heteroscedastic effect sizes
lme4 - for creating mixed effects models
ggpmisc - for labelling a plot with regression coefficients and R^2 values
bbmle - for fitting maximum likelihood models more efficiently

The script is divided into a few sections:

1) Loading of packages, cleaning of data, and visualization of data
2) Analysis:
2a) Regression of corticosterone against infection load
2b) Evaluation of treatment type on measured corticosterone

# Leopard_Frog_Swab_Analysis.R details

The data this script uses is Leopard_Frog_Data.csv. For more information regarding the data, checkout the README file associated with it. 

The packages utilized in this script include pacman, the tidyverse, emmeans, performance, glmmTMB, ggthemes, ggsignif, plotrix, wrappedtools, CR2, lme4, ggpmisc, and bbmle. Each package was used for specific purposes:

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
emmeans - for estimating confidence intervals 
performance - for evaluating linear model assumptions
glmmTMB - for creating generalized linear models and mixed effects models
ggthemes - for adding more theme options for ggplot plots
ggsignif - for estimating statistical significance and plotting p-values on graphs made with ggplot
plotrix - for estimate standard error of the median
wrappedtools - for creating tables 
CR2 - for estimating heteroscedastic effect sizes
lme4 - for creating mixed effects models
ggpmisc - for labelling a plot with regression coefficients and R^2 values
bbmle - for fitting maximum likelihood models more efficiently

The script is divided into a few sections:

1) Loading of packages, cleaning of data, and visualization of data
2) Evaluation of treatment type on measured corticosterone

# Survival_Analysis.R 

The data this script used was Survival_Analysis_Data.csv. For more information regarding the data, checkout the README file found in association with it. 

The packages utilized in this script include pacman, tidyverse, survival, lubridate, ggsurvfit, gtsummary, contsurvplot, pammtools, ggthemes, and survminer. Each package was used for specific purposes:

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
survival - for modeling kaplan-meier survival curves and cox regressions
lubridate - to recode temporal data into formats ammenable for data analysis and plotting
ggsurvfit - to generate summary figures of kaplan-meier or cox regressions; in addition, it can be used to evaluate model assumptions
gtsummary - to generate summary tables for kaplan-meier or cox regressions
contsurvplot - to display continuous variables on a cox regression survival curve plot
pammtools - to make piece-wise exponential additive mixed models for time-to-event data
ggthemes - to enable more theme options for plots generated using ggplot()
survminer - contains the function ggsurvplot(), which was used to plot survival curves

The script is divided into two sections: 
1) Loading of packages, cleaning of data, brief summaries of the data
2) Survival analysis using cox regressions