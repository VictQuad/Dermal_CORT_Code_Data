### Load in Libraries and Establish Settings ###
library(pacman)
p_load(tidyverse, emmeans, performance,
       glmmTMB, ggthemes, ggsignif, plotrix, 
       wrappedtools, CR2, lme4, ggpmisc, bbmle)
theme_set(theme_clean())
set.seed(62823)

### Load in Data and Clean it ###
Injections <- read_csv("") #load in ACTH_Injection_data.csv

Injections_clean <- Injections |>
  pivot_longer(names_to = "Time_corticosterone",
               values_to = "Corticosterone",
               cols = starts_with("Cort_")) |>
  pivot_longer(names_to = "Time_cortisol",
               values_to = "Cortisol",
               cols = starts_with("Cortisol")) |>
  pivot_longer(names_to = "Swab_time",
               values_to = "Bd_load",
               cols = starts_with("Bd_"))

### Visualize Results ###
Cort_Val <- Injections_clean |>
  filter(Time_corticosterone != "Cort_Field",
         Time_corticosterone != "Cort_Week1",
         Group != "None") |>
  mutate(Time_corticosterone = recode(Time_corticosterone,
                                      "Cort_0_Week3" = 0,
                                      "Cort_0.5" = 0.5,
                                      "Cort_1" = 1,
                                      "Cort_2" = 2,
                                      "Cort_3" = 3,
                                      "Cort_6" = 6,
                                      "Cort_24" = 24)) |>
  mutate(Time_corticosterone = as.factor(Time_corticosterone)) |>
  group_by(Group, Time_corticosterone) |>
  mutate(Med_cort = median(Corticosterone, na.rm = TRUE),
         Stem_cort = medianse(Corticosterone),
         Mean_cort = mean(Corticosterone, na.rm = TRUE),
         Ste_cort = std.error(Corticosterone, na.rm = TRUE)) |>
  ungroup() # This makes the data more amenable to plotting

dynamics <- ggplot(data = Cort_Val,
       mapping = aes(x = Time_corticosterone,
                     y = Med_cort,
                     color = Group)) +
  geom_point() +
  geom_line(mapping = aes(group = Group),
            linewidth = 0.6) +
  geom_errorbar(aes(ymax = Med_cort + Stem_cort,
                    ymin = Med_cort - Stem_cort),
                linewidth = 0.6) +
  labs(x = "Time (hours)",
       y = "Median Corticosterone(pg/ml)")
dynamics + scale_color_colorblind()

dynamics2 <- ggplot(data = Cort_Val,
                   mapping = aes(x = Time_corticosterone,
                                 y = Mean_cort,
                                 color = Group)) +
  geom_point() +
  geom_line(mapping = aes(group = Group),
            linewidth = 0.6) +
  geom_errorbar(aes(ymax = Mean_cort + Ste_cort,
                    ymin = Mean_cort - Ste_cort),
                linewidth = 0.6) +
  labs(x = "Time (hours)",
       y = "Mean Corticosterone(pg/ml)")
dynamics2 + scale_color_colorblind()

treatment_effects <- ggplot(data = Cort_Val,
                            mapping = aes(x = Group,
                                          y = Corticosterone,
                                          fill = Group)) +
  geom_boxplot() +
  labs(title = "CORT Detected According to Treatment",
       subtitle = "Obtained from Eastern Newts",
       x = "Injection Group",
       y = "Corticosterone (pg/ml)")
  
treatment_effects

Bd_cort <- Injections_clean |>
  filter(Time_corticosterone == c("Cort_Field", "Cort_Week1")) |>
  mutate(Time_corticosterone_c = recode(Time_corticosterone,
                                      "Cort_Week1" = "Week 1 (Captivity)",
                                      "Cort_Field" = "Field"),
         Dummy_variable = recode(Time_corticosterone,
                                 "Cort_Week1" = "1",
                                 "Cort_Field" = "0"))

ggplot(data = Bd_cort,
       mapping = aes(x = Time_corticosterone_c,
                     y = Corticosterone,
                     fill = Time_corticosterone)) +
  geom_boxplot() +
  geom_signif(comparisons = list(c("Field", "Week 1 (Captivity)")),
              map_signif_level = TRUE) +
  labs(title = "Baseline CORT in Wild vs Captive Newts",
       x = "Living Condition",
       y = "Corticosterone (pg/ml)") + 
  guides(fill=guide_legend(title="Living Condition"))

ggplot(data = Bd_cort,
       mapping = aes(x = Time_corticosterone_c,
                     y = log(Bd_load),
                     fill = Time_corticosterone)) +
  geom_boxplot() +
  geom_signif(comparisons = list(c("Field", "Week 1 (Captivity)")),
              map_signif_level = TRUE,
              y_position = 3.8) +
  labs(title = "Infection Burden in Wild vs Captive Newts",
       x = "Living Condition",
       y = "log Amplification Cycles (log(Cq))",
       subtitle = "Determined via Bd qPCR") +
  guides(fill=guide_legend(title="Living Condition"))

ggplot(data = Bd_cort,
       mapping = aes(x = as.numeric(Dummy_variable),
                     y = log(Bd_load))) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(title = "Chytrid Load in Wild vs Captive Newts",
       x = "Living Condition",
       y = "log ITS Starting Copy Numbers (log(Sq))",
       subtitle = "Determined via Bd qPCR") +
  guides(fill=guide_legend(title="Living Condition")) +
  stat_poly_eq(use_label(c("eq", "R2")))

### Analysis ###
cortbd_s <- lm(log(Corticosterone) ~ SVL,
               data = Bd_cort)

cortbd_w <- lm(log(Corticosterone) ~ Weight,
               data = Bd_cort)
check_model(cortbd_w)
check_model(cortbd_s) 
summary(cortbd_s) #SVL is a good predictor of CORT - needs to be included in model
summary(cortbd_w)
AICctab(cortbd_s,cortbd_w)

cortbd_lm1 <- lm(Bd_load ~ log(Corticosterone) + SVL,
                data = Bd_cort)
cortbd_lm2 <- lm(Bd_load ~ log(Corticosterone),
                 data = Bd_cort)
cortbd_lm3 <- lm(Bd_load ~ log(Corticosterone)*SVL,
                 data = Bd_cort)

check_model(cortbd_lm1)
check_model(cortbd_lm2)
check_model(cortbd_lm3)

cortbd_lme1 <- lmer(Bd_load ~ log(Corticosterone) + SVL + (1|Newt_ID),
                      data = Bd_cort)
cortbd_lme2 <- lmer(Bd_load ~ log(Corticosterone) + (1|Newt_ID),
                    data = Bd_cort)

check_model(cortbd_lme1)
check_model(cortbd_lme2)

anova(cortbd_lm2, cortbd_lm1) #SVL needs to be included
anova(cortbd_lm1, cortbd_lm3) #the interaction is not that important
AICctab(cortbd_lm1, cortbd_lm2, cortbd_lme1, cortbd_lm3, cortbd_lme2) #cortbd_lme2 is the best model
check_heteroskedasticity(cortbd_lme2)

effect<- effects::effect(term = "log(Corticosterone)", mod = cortbd_lme2) |>
  as_tibble()

ggplot(data = Bd_cort,
       mapping = aes(x = log(Corticosterone),
                     y = Bd_load)) +
  geom_point() +
  geom_line(data = effect, 
            aes(x =log(`Corticosterone`), 
                y = fit), 
            color = "red",
            linewidth = 1) +
  geom_ribbon(data = effect, 
              aes(x = log(Corticosterone), 
                                ymin = lower, 
                                ymax = upper),
              inherit.aes = FALSE,
              alpha = 0.3,
              fill = "royalblue",
              color = "blue",
              linewidth = 0.8) +
  labs(x = "log Corticosterone [log(pg/ml)]",
       y = "log ITS Starting Copy Number [log(Sq)]") +
  stat_poly_eq(use_label(c("eq", "R2")))
  
  

#Physiological Validation Models#
cortval_lm1 <- lm(log(Corticosterone) ~ Group + Time_corticosterone,
                  data = Cort_Val)
check_model(cortval_lm1)
cortval_lm2 <- lm(log(Corticosterone) ~ Group + Time_corticosterone + SVL,
                  data = Cort_Val)
check_model(cortval_lm2)
cortval_lm3 <- lm(log(Corticosterone) ~ Time_corticosterone + SVL,
                  data = Cort_Val)
check_model(cortval_lm3)
cortval_lm4 <- lm(log(Corticosterone) ~ Group,
                  data = Cort_Val)
check_model(cortval_lm4)
cortval_lme1 <- lmer(log(Corticosterone) ~ Group + Time_corticosterone + (1|Newt_ID),
                       data = Cort_Val)
check_model(cortval_lme1)
cortval_lme2 <- lmer(log(Corticosterone) ~ Group + Time_corticosterone + SVL + (1|Newt_ID),
                     data = Cort_Val)
check_model(cortval_lme2)
cortval_lme3 <- lmer(log(Corticosterone) ~ Group + (1|Newt_ID),
                     data = Cort_Val)
check_model(cortval_lme3)
AICctab(cortval_lm1, cortval_lm2, cortval_lm3, cortval_lm4, cortval_lme1,cortval_lme2,cortval_lme3)
#lme1 or 2 is best model
check_heteroscedasticity(cortval_lme1)

emmeans(cortval_lme1, specs = ~Group) |>
  contrast(method = "trt.vs.ctrl") |>
  confint() |>
  plot() +
  geom_vline(xintercept = 0, color = "red", lty = 2) +
  labs(x = "Estimated Difference in Mean Corticosterone",
       y = "Groups Compared")
