### Loading in Libraries and Settings ###
library(pacman)
p_load(tidyverse, survival, lubridate, ggsurvfit, gtsummary, contsurvplot,
       pammtools, ggthemes, survminer)
theme_set(theme_clean())

### Loading in and Cleaning the Data ###
survival <- read_csv("") #load in Survival_Analysis_Data.csv |>
  na.omit(survival)

survival <- survival |>
  mutate(`Date Collected` = mdy(`Date Collected`),
         `End Date` = mdy(`End Date`),
         Days_Survived =`End Date` - `Date Collected`,
         Del_Load = `Load Acc` - `Load Field`,
         Del_CORT = Cort_W1 - Cort_Field,
         Body_Cond = Mass/(SVL^2)) 

### Survival Modeling ###

survfit2(Surv(Days_Survived, Status) ~ 1, data = survival) |> 
  ggsurvfit() +
  labs(
    x = "Days",
    y = "Overall survival probability",
    title = "Kaplan-Meier Survival Curve for Newt Cohort"
  ) +
  add_confidence_interval()

survival <- survival |>
  mutate(Days_Survived = as.numeric(Days_Survived))

modelz <- coxph(Surv(Days_Survived, Status) ~ SVL, data = survival, x = TRUE)
summary(modelz)
cox.zph(modelz) |>
  ggcoxzph()
ggcoxdiagnostics(modelz, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(modelz, type = "martingale",
                 linear.predictions = TRUE)


plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "SVL",
               data = survival,
               model = modelz) +
  labs(title = "Cox Survival Curves According to Snout-Vent Length",
       color = "Snout-Vent Length (mm)")

model1 <- coxph(Surv(Days_Survived, Status) ~ `Load Acc`, data = survival, x = TRUE)
summary(model1)
cox.zph(model1) |>
  ggcoxzph()
ggcoxdiagnostics(model1, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(model1, type = "martingale",
                 linear.predictions = TRUE)

plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "Load Acc",
               data = survival,
               model = model1) +
  labs(color = "log ITS Starting Copy Numbers")

model2 <- coxph(Surv(Days_Survived, Status) ~ Cort_W1, data = survival, x = TRUE)
summary(model2)
cox.zph(model2) |>
  ggcoxzph()
ggcoxdiagnostics(model2, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(model2, type = "martingale",
                 linear.predictions = TRUE)

plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "Cort_W1",
               data = survival,
               model = model2) +
  labs(color = "Corticosterone (pg/ml)")

model3 <- coxph(Surv(Days_Survived, Status) ~ Body_Cond, data = survival, x = TRUE)
summary(model3)
cox.zph(model3) |>
  ggcoxzph()
ggcoxdiagnostics(model3, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(model3, type = "martingale",
                 linear.predictions = TRUE)

plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "Body_Cond",
               data = survival,
               model = model3) +
  labs(title = "Cox Survival Curves According to Body Condition",
       color = "Body Condition (g/ml^2)")

model4 <- coxph(Surv(Days_Survived, Status) ~ `Load Field`, data = survival, x = TRUE)
summary(model4)
cox.zph(model4) |>
  ggcoxzph()
ggcoxdiagnostics(model4, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(model4, type = "martingale",
                 linear.predictions = TRUE)

plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "Load Field",
               data = survival,
               model = model4) +
  labs(title = "Cox Survival Curves According to Field Load",
       color = "log(Bd Copy Numbers)")

model5 <- coxph(Surv(Days_Survived, Status) ~ Cort_Field, data = survival, x = TRUE)
summary(model5)
cox.zph(model5) |>
  ggcoxzph()
ggcoxdiagnostics(model5, type = "deviance",
                 linear.predictions = FALSE)
ggcoxdiagnostics(model5, type = "martingale",
                 linear.predictions = TRUE)

plot_surv_area(time = "Days_Survived",
               status = "Status",
               variable = "Cort_Field",
               data = survival,
               model = model5) +
  labs(title = "Cox Survival Curves According to Field CORT",
       color = "Corticosterone (pg/ml)")

ggplot(mapping = aes(x = Del_Load,
                     y = Del_CORT),
       data = survival) +
  geom_point() +
  geom_smooth(method = "lm")
