### Validation Experiments ###

The 2 R files provided contain scripts for analyzing validation data. Validation data includes both the wash assay and matrix experiment. The wash assay was performed to determine if a sterile water bath removes corticosterone from the skin of Eastern newts. The matrix experiment was performed to determine if rayon swabs are an effective matrix to uptake corticosterone AND if different medium types effect the ability of rayon swabs to adequately capture corticosterone. 

### CORT_Wash_Assay.R ### 

This script utilizes the Wash_Experiment_Summary_061523.csv file. For more information regarding the data, find the README file associated with it. 

The packages utilized in this script include pacman, the tidyverse, performance, emmeans, ggthemes, glmmTMB, ggsignif, and bbmle. Each package was used for a specific purpose: 

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
emmeans - for estimating confidence intervals 
performance - for evaluating linear model assumptions
glmmTMB - for creating generalized linear models and mixed effects models
ggthemes - for adding more theme options for ggplot plots
ggsignif - for estimating statistical significance and plotting p-values on graphs made with ggplot
bbmle - for fitting maximum likelihood models more efficiently

The script is divided into a few sections:

1) Loading of packages, cleaning of data, and visualization of data
2) Analysis:
2a) Evaluation of differences between 0 minute and 30 minute timepoints
2b) Evaluation of washing on the amount of detected corticosterone

### CORT_Swab_Matrix.R ###

This script utilizes the Wash_Experiment_Summary_061523.csv file. For more information regarding the data, find the README file associated with it. 

The packages utilized in this script include pacman, the tidyverse, performance, emmeans, ggthemes, glmmTMB, ggsignif, lme4. Each package was used for a specific purpose: 

pacman - for loading all of the packages required for analysis using p_load()
tidyverse - for loading dplyr, ggplot2, purr, and many other packages contained in the tidyverse family of packages
emmeans - for estimating confidence intervals 
performance - for evaluating linear model assumptions
glmmTMB - for creating generalized linear models and mixed effects models
ggthemes - for adding more theme options for ggplot plots
ggsignif - for estimating statistical significance and plotting p-values on graphs made with ggplot
lme4 - for creating mixed effects models

The script is divided into a few sections:

1) Loading of packages, cleaning of data, and visualization of data
2) Analysis:
2a) Evaluation of differences between spiked and unspiked media
2b) Evaluation of medium type on measured corticosterone
