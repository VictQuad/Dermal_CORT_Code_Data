### Loading in Data and Settings ### 
library(pacman)
p_load(tidyverse, performance, emmeans,
       ggthemes, glmmTMB, ggsignif, bbmle)
set.seed(6152023)

### Load in Data ###
cort_data <- read_csv("") #load in Wash_Experiment_Summary_061523.csv

unspiked <- cort_data |>
  filter(Treatment == "Unspiked") |>
  mutate(Time = as.factor(Time),
         'Newt' = Sample)

### Visualization ### 
ggplot(data = unspiked,
       mapping = aes(x = Wash,
                     y = `[CORT]`,
                     fill = Wash)) +
  geom_boxplot() +
  labs(title = "Effect of Washing on Detected CORT through Swabbing",
       x = "Wash Group",
       y = "Corticosterone (pg/ml)",
       subtitle = "Obtained from Eastern Newts") +
  scale_fill_viridis_d(option = "D") +
  theme_clean() +
  geom_signif(comparisons = list(c("Unwashed", "Washed")))

ggplot(data = cort_data,
       mapping = aes(x = Treatment,
                     y = `[CORT]`,
                     fill = Treatment)) +
  geom_boxplot() +
  labs(title = "Spiked vs Unspiked CORT Recovered",
       x = "Sample Extract Group",
       y = "Corticosterone (pg/ml)",
       subtitle = "Obtained from Eastern Newts") +
  theme_clean() +
  geom_signif(comparisons = list(c("Spiked", "Unspiked")),
              map_signif_level = TRUE) +
  scale_fill_fivethirtyeight()

ggplot(data = unspiked,
       mapping = aes(x = Time,
                     y = `[CORT]`,
                     fill = Time)) +
  geom_boxplot() +
  labs(title = "Corticosterone Detected After Handling through Swabs",
       x = "Time (min)",
       y = "Corticosterone (pg/ml)",
       subtitle = "Obtained from Eastern Newts") +
  scale_fill_fivethirtyeight() +
  geom_signif(comparisons = list(c("0", "30"))) +
  theme_clean()

ggplot(data = unspiked,
       mapping = aes(x = Time,
                     y = `[CORT]`,
                     color = Newt)) +
  geom_line(aes(group = Newt)) +
  geom_point() +
  scale_color_viridis_d(option = "D") +
  labs(title = "Corticosterone Response in 30 minutes",
       x = "Time (min)",
       y = "Corticosterone (pg/ml)",
       subtitle = "Lines drawn per individual Eastern Newt") +
  theme_clean() +
  facet_grid(.~ Wash)

### Analysis ###
cort_lm <- lm(`[CORT]` ~ Wash + Time,
                 data = unspiked)
check_model(cort_lm)

cort_int <- lm(`[CORT]` ~ Wash*Time,
               data = unspiked)
check_model(cort_int)

cort_lme <- glmmTMB(`[CORT]` ~ Wash + Time + (1|Newt),
                 data = unspiked)
check_model(cort_lme)

cort_lme_int <- glmmTMB(`[CORT]` ~ Wash*Time + (1|Newt),
                     data = unspiked)
check_model(cort_lme_int)

AICctab(cort_lm, cort_int, cort_lme, cort_lme_int) #best one is the simple linear model

emmeans(cort_lm, specs = ~Time) |>
  contrast(method = "pairwise") |>
  confint() |>
  plot() +
  geom_vline(xintercept = 0, color = "red", lty = 2) +
  theme_clean() +
  labs(title = "95% Confidence Interval About the Mean Difference in CORT",
       subtitle = "0 minute to 30 minute comparison",
       x = "Estimated Mean Contrast",
       y = "Contrast Groups")

emmeans(cort_lm, specs = ~Wash) |>
  contrast(method = "pairwise") |>
  confint() |>
  plot() +
  geom_vline(xintercept = 0, color = "red", lty = 2) +
  theme_clean() +
  labs(title = "95% Confidence Interval About the Mean Difference in CORT",
       subtitle = "Washed to Unwashed comparison",
       x = "Estimated Mean Contrast",
       y = "Contrast Groups")
  
