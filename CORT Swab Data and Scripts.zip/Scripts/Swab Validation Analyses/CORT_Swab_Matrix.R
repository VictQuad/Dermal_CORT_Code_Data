### Loading Libraries ###
library(pacman)
p_load(tidyverse, ggthemes, ggsignif,
       emmeans, performance, lme4, glmmTMB)

### Loading in Data ###
validation <- read_csv("") #load in Cort_Swab_Validation_071123.csv

validation_swabspike <- validation |>
  filter(Treatment == "Swab Only Spike") |>
  mutate(efficiency = (mean(CORT)/2500)*100,
         deviation = (sd(CORT)/2500)*100)

validation_s <- validation |>
  filter(Treatment != "Swab Only Spike") |>
  group_by(Treatment) |>
  mutate(mean_CORT = mean(CORT),
         mean_SEM = mean(SEM)) |>
  ungroup()

validation_sp <- validation_s |>
  filter(Status == "Unspiked")

### Visualizations ###
ggplot(data = validation_s,
       mapping = aes(x = Treatment,
                     y = mean_CORT,
                     fill = Status)) +
  geom_col(position = "dodge",
           color = "black") +
  theme_clean() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  labs(x = "Treatment Group Swabbed",
       y = "Corticosterone (pg/ml)") +
  geom_hline(yintercept = 8.8, color = "red", lty = 2) +
  geom_errorbar(aes(ymin=mean_CORT-mean_SEM, ymax=mean_CORT+mean_SEM), width=.2,
                position=position_dodge(.9))

ggplot(data = validation_s,
       mapping = aes(x = Status,
                     y = CORT,
                     fill = Status,
                     color = Status)) +
  geom_boxplot(color = "black") +
  geom_signif(comparisons = list(c("Spiked", "Unspiked")),
              map_signif_level = TRUE,
              color = "black",
              test = "t.test") +
  scale_fill_pander() +
  theme_clean() +
  labs(x = "Sample Type Swabbed",
       y = "Corticosterone (pg/ml)")

ggplot(data = validation_sp,
       mapping = aes(x = Medium,
                     y = CORT,
                     fill = Medium,
                     color = Medium)) +
  geom_boxplot(color = "black",
               alpha = 2) +
  geom_point(alpha = 1.2,
              color = "black") +
  geom_signif(comparisons = list(c("Mucus", 'Swab')),
              map_signif_level = TRUE,
              y_position = 120,
              tip_length = 0.019,
              color = "black",
              test = "t.test") +
  geom_signif(comparisons = list(c("Mucus", 'Buffer')),
              map_signif_level = TRUE,
              y_position = 130,
              tip_length = 0.019,
              color = "black",
              test = "t.test") +
  geom_signif(comparisons = list(c("Mucus", 'Water')),
              map_signif_level = TRUE,
              y_position = 140,
              tip_length = 0.019,
              color = "black",
              test = "t.test") +
  theme_clean() +
  labs(x = "Medium Swabbed",
       y = "Corticosterone (pg/ml)") +
  scale_fill_pander()


### Statistical Analysis ###
swab_lm_t <- lm(data = validation_s,
                   formula = CORT ~ Treatment)
check_model(swab_lm_t)

swab_lm_m <- lm(data = validation_s,
                   formula = CORT ~ Medium)
check_model(swab_lm_m)

swab_lm_s <- lm(data = validation_s,
                CORT ~ Status)
check_model(swab_lm_s)

swab_lmm1 <- lm(data = validation_s,
                formula = CORT ~ Treatment + Medium)
check_model(swab_lmm1)

swab_lmi1 <- lm(data = validation_s,
                formula = CORT ~ Treatment*Medium)
check_model(swab_lmi1)

swab_lmm2 <- lm(data = validation_s,
                CORT ~ Treatment + Status)
check_model(swab_lmm2)

swab_lmi2 <- lm(data = validation_s,
                CORT ~ Treatment*Status)
check_model(swab_lmi2)

swab_lmm3 <- lm(data = validation_s,
                CORT ~ Medium + Status)
check_model(swab_lmm3)

swab_lmi3 <- lm(data = validation_s,
                CORT ~ Medium*Status)
check_model(swab_lmi3)

swab_lmm4 <- lm(data = validation_s,
                CORT ~ Medium + Status + Treatment)
check_model(swab_lmm4) #VIFs not sensible

swab_lmi4 <- lm(data = validation_s,
                CORT ~ Medium*Status*Treatment)
check_model(swab_lmi4)

AIC(swab_lm_t, swab_lm_m, swab_lmm1, swab_lmi1, 
    swab_lmm2, swab_lmi2, swab_lmm3, swab_lmi3,
    swab_lmm4, swab_lmi4, swab_lm_s) #(use swab_lmi4 -> best fit + lowest AIC)

summary(swab_lmm4) #Adjusted R-squared 0.9767, 14 df

emmeans(swab_lmm4, specs=~ Medium) %>%
  contrast("tukey") %>%
  confint() %>%
  plot() +
  geom_vline(xintercept = 0,lty = 2, color = "red") +
  theme_clean() +
  labs(title = "95% Confidence Intervals for Mean Corticosterone",
       subtitle = "Pairwise Comparisons Between Medium Types",
       x = "Difference Between Mean [CORT] (pg/ml)",
       y = "Medium-Medium Comparisons")

emmeans(swab_lmm4, specs =~ Treatment) |>
  contrast("tukey") |>
  confint() |>
  plot() +
  geom_vline(xintercept = 0, lty = 2, color = "red") +
  theme_clean()+
  labs(title = "95% Confidence Intervals for Mean Corticosterone",
       subtitle = "Effect Estimation from Overall Mean",
       x = "Difference Between Mean [CORT] (pg/ml)",
       y = "Spiked/Unspiked to Medium Comparisons")
 